export const setBeerName=(name)=>({
  type:"SET_NAME_FILTER",
  name
})